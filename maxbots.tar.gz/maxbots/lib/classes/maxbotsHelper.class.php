<?php

class maxbotsHelper extends waAppConfig
{
    
}
