<?php 

class maxbotsViewHelper extends waAppViewHelper
{

}