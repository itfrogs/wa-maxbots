<?php

class maxbotsPlugin extends waPlugin
{
       
}
