<?php
return array (
    'name' => 'Max bots',
    'icon' =>
        array (
            48 => 'img/maxbots48.png',
            96 => 'img/maxbots96.png',
            24 => 'img/maxbots24.png',
            16 => 'img/maxbots16.png',
        ),
    'version' => '1.0.1',
    'vendor' => '964801',
    'ui' => '2.0',
    'plugins' => true,
    'frontend' => true,
    'routing_params' => array(
        'private' => true,
    ),
);
