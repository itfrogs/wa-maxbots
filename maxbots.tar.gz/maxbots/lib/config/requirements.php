<?php

return array(
    'php' => array(
        'strict' => true,
        'version' => '>=8.2.0',
    ),
    'app.installer' => [
        'version' => '3.1.0',
        'strict' => true
    ],
);